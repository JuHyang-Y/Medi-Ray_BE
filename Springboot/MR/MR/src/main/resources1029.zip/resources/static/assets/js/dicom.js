document.addEventListener('DOMContentLoaded', function () {
  const fileInput = document.getElementById('fileInput');
  const selectFilesBtn = document.getElementById('selectFilesBtn');
  const uploadBox = document.getElementById('upload-box');
  const previewContainer = document.getElementById('preview-container');
  const previewImage = document.getElementById('preview-image');
  const closePreviewBtn = document.querySelector('.close-preview');
  const submitBtn = document.getElementById('submitBtn');
  const cancelBtn = document.getElementById('cancelBtn');
  const userInfoDiv = document.getElementById('user-info');

  // 가짜 로그인된 사용자 정보 (실제로는 서버나 로컬 스토리지에서 가져와야 함)
  const loggedInUser = {
    name: '신속주', // 로그인된 사용자 이름 예시
    isLoggedIn: true, // 로그인 상태
  };

  // 로그인된 사용자 정보를 표시하는 함수
  function renderUserInfo() {
    if (loggedInUser.isLoggedIn) {
      // 로그인 상태일 때
      userInfoDiv.innerHTML = `
          <i class="fas fa-user-circle text-2xl"></i>
          <span class="text-lg font-semibold">${loggedInUser.name} 님</span>
          <button id="logoutBtn" class="text-red-500 text-lg">로그아웃</button>
        `;
      document
        .getElementById('logoutBtn')
        .addEventListener('click', function () {
          alert('로그아웃 되었습니다.');
          // 실제 로그아웃 로직을 여기서 처리합니다. 예: 서버 요청, 로컬 스토리지 정리 등
          loggedInUser.isLoggedIn = false;
          renderUserInfo(); // 로그아웃 후 UI 업데이트
        });
    } else {
      // 비로그인 상태일 때
      userInfoDiv.innerHTML = `
          <i class="fas fa-user-circle text-2xl"></i>
          <button id="loginBtn" class="text-blue-500 text-lg">로그인</button>
        `;
      document
        .getElementById('loginBtn')
        .addEventListener('click', function () {
          alert('로그인 페이지로 이동합니다.');
          // 로그인 페이지로 이동하는 로직을 여기서 처리합니다.
          window.location.href = '/login'; // 예시로 로그인 페이지 이동
        });
    }
  }

  // 사용자 정보 렌더링
  renderUserInfo();

  // 파일 선택 버튼 클릭 시 파일 입력 창 열기
  selectFilesBtn.addEventListener('click', function () {
    fileInput.click();
  });

  // 파일 선택 또는 드래그 앤 드롭 시 파일 미리보기 처리
  fileInput.addEventListener('change', handleFileUpload);
  uploadBox.addEventListener('dragover', function (event) {
    event.preventDefault(); // 기본 동작 방지 (드래그 앤 드롭)
  });

  uploadBox.addEventListener('drop', function (event) {
    event.preventDefault();
    const files = event.dataTransfer.files;
    if (files.length > 0) {
      fileInput.files = files;
      handleFileUpload();
    }
  });

  // 파일 업로드 시 미리보기 처리 함수
  function handleFileUpload() {
    const file = fileInput.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = function (event) {
        previewImage.src = event.target.result;
        previewContainer.classList.remove('hidden');
        uploadBox.classList.add('hidden'); // 파일 업로드 후 업로드 박스 숨기기
        submitBtn.classList.add('hidden'); // 전송 버튼 숨기기
        cancelBtn.classList.add('hidden'); // 취소 버튼 숨기기
      };
      reader.readAsDataURL(file);
    } else {
      alert('이미지 파일만 업로드 가능합니다.');
    }
  }

  // 미리보기 닫기 버튼
  closePreviewBtn.addEventListener('click', function () {
    previewContainer.classList.add('hidden');
    uploadBox.classList.remove('hidden'); // 미리보기 닫으면 업로드 박스 다시 표시
    submitBtn.classList.remove('hidden'); // 전송 버튼 다시 표시
    cancelBtn.classList.remove('hidden'); // 취소 버튼 다시 표시
    fileInput.value = ''; // 파일 선택 초기화
  });

  // 전송 버튼 클릭 시 (예시 데이터 전송)
  submitBtn.addEventListener('click', function () {
    alert('파일이 전송되었습니다.');
    // 여기서 실제 파일 전송 로직을 구현할 수 있습니다.
  });

  // 취소 버튼 클릭 시
  cancelBtn.addEventListener('click', function () {
    previewContainer.classList.add('hidden');
    uploadBox.classList.remove('hidden'); // 취소 시 업로드 박스 다시 표시
    submitBtn.classList.remove('hidden'); // 전송 버튼 다시 표시
    cancelBtn.classList.remove('hidden'); // 취소 버튼 다시 표시
    fileInput.value = ''; // 파일 선택 초기화
  });

  // 환자 정보 예시 데이터 (임시로 JavaScript로 동적 추가)
  const patientInfoBody = document.getElementById('patient-info-body');
  const samplePatientData = [
    { code: '24-0001', name: '이순신', age: 56, gender: '남', doctor: '허준' },
    {
      code: '24-0002',
      name: '홍길동',
      age: 42,
      gender: '남',
      doctor: '이석규',
    },
  ];

  // 환자 정보 테이블 렌더링
  function renderPatientInfo() {
    patientInfoBody.innerHTML = '';
    samplePatientData.forEach((patient) => {
      const row = document.createElement('tr');
      row.innerHTML = `
          <td class="border px-4 py-2">${patient.code}</td>
          <td class="border px-4 py-2">${patient.name}</td>
          <td class="border px-4 py-2">${patient.age}</td>
          <td class="border px-4 py-2">${patient.gender}</td>
          <td class="border px-4 py-2">${patient.doctor}</td>
        `;
      patientInfoBody.appendChild(row);
    });
  }

  // 환자 정보 렌더링 호출
  renderPatientInfo();
});
