document.addEventListener('DOMContentLoaded', function () {
  const searchBtn = document.getElementById('searchBtn');
  const patientTableBody = document.getElementById('patientTableBody');
  const userInfo = document.getElementById('user-info');
  const backBtn = document.getElementById('backBtn');

  // 사용자 이름 (로그인 상태라고 가정)
  const loggedInUser = '신속주 님';

  // 로그인 정보 표시
  renderUserInfo();

  // 검색 버튼 클릭 시 서버에 요청 보내기
  searchBtn.addEventListener('click', function () {
    const ptName = document.getElementById('ptName').value.trim();

    if (ptName === '') {
      alert('환자 이름을 입력해주세요.');
      return;
    }

    const url = `/diagnosis/search?ptName=${encodeURIComponent(ptName)}`;
    // console.log(url);

    // 서버로부터 데이터를 가져오는 부분
    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error('서버 응답 오류');
        }
        return response.json();
      })
      .then(data => {
        renderPatientTable(data); // 받아온 데이터를 테이블에 렌더링
      })
      .catch(error => {
        console.error('데이터 가져오기 중 오류 발생:', error);
        alert('환자 데이터를 가져오는 중 오류가 발생했습니다.');
      });
  });

  // 테이블 데이터 렌더링 함수
  function renderPatientTable(patients) {
    patientTableBody.innerHTML = ''; // 기존 데이터 초기화

    if (patients.length === 0) {
      patientTableBody.innerHTML = `<tr><td colspan="5" class="border px-4 py-2">검색 결과가 없습니다</td></tr>`;
    } else {
      patients.forEach((patient) => {
        const row = document.createElement('tr');
        /*여기서 어떻게 url을 넘어 갈 것인지 설정해줘야함*/
        row.innerHTML = `
            <td class="border px-4 py-2">${patient.ptCode}</td>
            <td class="border px-4 py-2">
              <a href="diagnosis/xray" class="text-blue-500 hover:underline">${patient.ptName}</a>
            </td>
            <td class="border px-4 py-2">${patient.ptBirthdate}</td>
            <td class="border px-4 py-2">${patient.ptGen}</td>
            <td class="border px-4 py-2">${patient.dtCode}</td>
          `;
        patientTableBody.appendChild(row);
      });
    }
  }

  // 로그인 정보 표시 함수
  function renderUserInfo() {
    const userHtml = `
        <i class="fas fa-user-circle text-2xl"></i>
        <span class="text-lg font-semibold">${loggedInUser}</span>
        <button class="text-red-500 text-lg" id="logoutBtn">로그아웃</button>
      `;
    userInfo.innerHTML = userHtml;

    // 로그아웃 버튼 클릭 이벤트
    const logoutBtn = document.getElementById('logoutBtn');
    logoutBtn.addEventListener('click', function () {
      alert('로그아웃 되었습니다.');
      window.location.href = '/login'; // 로그인 페이지로 이동
    });
  }

  // 뒤로가기 버튼 클릭 시
  if (backBtn) {
    backBtn.addEventListener('click', function () {
      window.history.back(); // 이전 페이지로 이동
    });
  }
});
