document.addEventListener('DOMContentLoaded', function() {
	const canvas = document.getElementById('diagnosisCanvas');
	const camCanvas = document.getElementById('camCanvas');
	const dicomCanvas = document.getElementById('dicomCanvas');

	const ctx = canvas.getContext('2d');
	const camCtx = camCanvas.getContext('2d'); // CAM 전용 canvas context
	const dicomCtx = dicomCanvas.getContext('2d'); // DICOM 전용 canvas context

	let uploadedImage = null; // DICOM 이미지를 저장할 변수


	// 초기 캔버스 크기 저장
	let canvasWidth = canvas.width;
	let canvasHeight = canvas.height;

	// 이전 캔버스 크기 저장
	let prevCanvasWidth = canvasWidth;
	let prevCanvasHeight = canvasHeight;

	// Canvas
	const brushToolButton = document.getElementById('brushTool');
	const rectangleToolButton = document.getElementById('rectangleTool');
	const colorPicker = document.getElementById('colorPicker');
	const brushSize = document.getElementById('brushSize');

	// Cam, dicom
	/*const loadImageBtn = document.getElementById('loadImageBtn');*/
	const imageLoader = document.getElementById('imageLoader');
	/*const xrayCode = localStorage.getItem('xrayCode');*/
	const doctorOpinionTextarea = document.querySelector('textarea[placeholder="의사 소견 입력"]');
	const saveButton = document.getElementById('opSubmit'); // 저장 버튼 선택
	const paginationContainer = document.getElementById('pagination'); // 페이지네이션 컨테이너 추가
	const itemsPerPage = 3; // 한 페이지에 표시할 항목 수
	let currentPage = 1;
	let data = []; // 서버에서 가져온 데이터를 저장할 배열

	//CAM 실행할 때 필요한 아이들
	let heatmapActive = false; // Track if heatmap is active

	// Canvas 실행할 때 필요한 아이들
	let isDrawing = false;
	let startX, startY;
	let currentTool = 'brush';
	let selectedColor = '#000000';
	let selectedSize = 5;

	// URL 파라미터에서 ptCode 가져오기
	const urlParams = new URLSearchParams(window.location.search);
	const ptCode = urlParams.get('ptCode');
	let xrayCode = localStorage.getItem('xrayCode');
	

	// localStorage에 `xrayCode`가 있으면 즉시 의견을 업데이트
	if (xrayCode) {
		fetchOpinionAndUpdate();
		// 페이지가 변경될 때마다 호출 (예: xrayCode가 바뀔 때마다 호출)
		fetchDiagnosisResults(xrayCode);
		const xrayImgPath = `/diagnosis/xray/getImage?xrayCode=${encodeURIComponent(xrayCode)}`;
		loadImageToCanvas(xrayImgPath);
		/*loadImageByXrayCode(xrayCode);*/
	} else {
		console.error('localStorage에 xrayCode가 없습니다.');
	}


	console.log('Loaded xrayCode:', xrayCode); // 받아온 값 확인
	console.log('Received ptCode:', ptCode);

	// Canvas API
	// 화면 크기에 맞게 캔버스를 리사이즈하는 함수
	function resizeCanvas() {
		scaleCanvasContent();
		const containerWidth = canvas.parentElement.clientWidth;
		const containerHeight = canvas.parentElement.clientHeight;

		// 현재 내용을 저장
		const tempCanvas = document.createElement('canvas');
		tempCanvas.width = canvas.width;
		tempCanvas.height = canvas.height;
		tempCanvas.getContext('2d').drawImage(dicomCanvas, 0, 0);

		// HTML 요소의 너비와 높이에 맞추어 캔버스 크기 조정
		canvas.width = containerWidth;
		canvas.height = containerHeight;
		camCanvas.width = containerWidth;
		camCanvas.height = containerHeight;
		dicomCanvas.width = containerWidth;
		dicomCanvas.height = containerHeight;
	}

	// 창 크기가 변경될 때마다 캔버스를 리사이즈
	window.addEventListener('resize', resizeCanvas);
	resizeCanvas(); // 초기 로딩 시 한 번 호출
	scaleCanvasContent();

	// Tool selection
	brushToolButton.addEventListener('click', () => (currentTool = 'brush'));
	rectangleToolButton.addEventListener('click', () => (currentTool = 'rectangle'));

	// Update color and size
	colorPicker.addEventListener('input', (e) => (selectedColor = e.target.value));
	brushSize.addEventListener('input', (e) => (selectedSize = e.target.value));

	// Canvas event listeners for drawing
	canvas.addEventListener('mousedown', (e) => {
		isDrawing = true;
		startX = e.offsetX;
		startY = e.offsetY;
	});

	canvas.addEventListener('mousemove', (e) => {
		if (!isDrawing) return;

		if (currentTool === 'brush') {
			ctx.lineWidth = selectedSize;
			ctx.lineCap = 'round';
			ctx.strokeStyle = selectedColor;
			ctx.beginPath();
			ctx.moveTo(startX, startY);
			ctx.lineTo(e.offsetX, e.offsetY);
			ctx.stroke();
			startX = e.offsetX;
			startY = e.offsetY;
			
		}
	});

	canvas.addEventListener('mouseup', (e) => {
		e.preventDefault();
		isDrawing = false;

		if (currentTool === 'rectangle') {
			const rectWidth = e.offsetX - startX;
			const rectHeight = e.offsetY - startY;
			ctx.strokeStyle = selectedColor;
			ctx.lineWidth = selectedSize;
			ctx.strokeRect(startX, startY, rectWidth, rectHeight);
		}
	});

	// Clear only drawings on the canvas, keep uploaded image
	// Clear 버튼 기능: 드로잉 및 CAM만 지우고 DICOM 이미지는 유지
	document.getElementById('clearCanvas').addEventListener('click', () => {
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		drawDicomImage(); // Reset DICOM image on clear
		ctx.restore();
	});


	// CAM button functionality
	document.getElementById('camButton').addEventListener('click', () => {
		heatmapActive = !heatmapActive;

		if (heatmapActive) {
			// Simulate heatmap by overlaying color spots on the canvas
			// CAM 효과를 추가하기 전에 현재 캔버스 상태를 저장
			drawHeatmap();
			document.getElementById('camButton').textContent = 'Hide CAM';
		} else {
			// Clear heatmap and redraw uploaded image if available
			camCtx.clearRect(0, 0, camCanvas.width, camCanvas.height);
			document.getElementById('camButton').textContent = 'Show CAM';
		}
	});

	function drawHeatmap() {
		// Placeholder heatmap rendering logic
		camCtx.globalAlpha = 0.5; // Set transparency for heatmap effect
		camCtx.fillStyle = 'rgba(255, 0, 0, 0.5)'; // Red color for heatmap area
		camCtx.beginPath();
		camCtx.arc(camCanvas.width / 2, camCanvas.height / 2, 100, 0, 2 * Math.PI); // Central red spot
		camCtx.fill();

		camCtx.fillStyle = 'rgba(0, 255, 0, 0.3)'; // Green color for heatmap area
		camCtx.beginPath();
		camCtx.arc(camCanvas.width / 4, camCanvas.height / 4, 60, 0, 2 * Math.PI); // Green spot
		camCtx.fill();

		camCtx.globalAlpha = 1.0; // Reset transparency
	}


	// 촬영 리스트 데이터 가져오기
	fetch(`/diagnosis/xray/dateList?ptCode=${encodeURIComponent(ptCode)}`)
		.then(response => response.json())
		.then(fetchedData => {
			data = fetchedData; // 데이터 저장
			renderPage(); // 첫 페이지 렌더링
			renderPagination(); // 페이지네이션 렌더링
		})
		.catch(error => {
			console.error('Error fetching dateList:', error);
		});

	// 페이지 렌더링 함수
	function renderPage() {
		//        patientList.innerHTML = ''; // 기존 내용 지우기
		const startIndex = (currentPage - 1) * itemsPerPage;
		const endIndex = startIndex + itemsPerPage;
		const itemsToDisplay = data.slice(startIndex, endIndex);

		document.querySelectorAll('#patientList > li > button').forEach(item => {
			item.innerText = ""
		})

		// console.log(document.querySelectorAll('#patientList > li > button'))

		// 촬영리스트에 값 할당하기
		itemsToDisplay.forEach((item, index) => {
			const button = document.getElementById(`patientBtn${index}`);
			button.innerText = item.xrayDate;
			/*index = 0
			document.getElementById('patientBtn0').innerText=data[( 3 * (currentPage - 1))+index++].xrayDate
			document.getElementById('patientBtn1').innerText=data[( 3 * (currentPage - 1))+index++].xrayDate
			document.getElementById('patientBtn2').innerText=data[( 3 * (currentPage - 1))+index++].xrayDate*/


			// 버튼 클릭 이벤트 - AJAX를 사용해 데이터 전송
			button.onclick = function() {
				fetch(`/diagnosis/xray/imgDate?ptCode=${encodeURIComponent(ptCode)}&xrayDate=${encodeURIComponent(item.xrayDate)}`)
					.then(response => response.json())
					.then(imgData => {
						console.log("Received data:", imgData); // 받은 데이터를 콘솔에 출력
						updateScreen(imgData); // 화면에 데이터 업데이트
						localStorage.setItem('xrayCode', xrayCode); // localStorage에 새로운 xrayCode 저장

	                    // 선택된 xrayCode에 맞는 이미지와 의견 업데이트
	                    updateScreen(imgData); 
	                    fetchOpinionAndUpdate(); // 의견 업데이트
	                    // 페이지가 변경될 때마다 호출 (예: xrayCode가 바뀔 때마다 호출)
						fetchDiagnosisResults(xrayCode);

					})
					.catch(error => console.error('Error fetching imgDate data:', error));
					
			};
		});
	}


	// 이미지 로딩 후 캔버스에 표시
	function loadImageToCanvas(imgUrl) {
		const img = new Image();
		img.crossOrigin = "anonymous"; // CORS 설정 (서버에서 CORS가 허용되는 경우에만 필요)
		img.onload = () => {
			uploadedImage = img;
			drawDicomImage(); // 이미지 다시 그리기
			adjustCanvasSize(); // 이미지 로드 후 canvas 크기 조정
		};
		img.src = imgUrl; // 이미지 경로 설정
	}

	// DICOM 비율에 맞춰 Canvas 크기 조정
	function adjustCanvasSize() {
		if (uploadedImage) {
			const aspectRatio = uploadedImage.width / uploadedImage.height;

			// 이전 캔버스 크기 저장
			prevCanvasWidth = canvasWidth;
			prevCanvasHeight = canvasHeight;

			// DICOM Canvas 비율 조정
			dicomCanvas.width = dicomCanvas.parentElement.clientWidth;
			dicomCanvas.height = dicomCanvas.width / aspectRatio;

			// 다른 캔버스 크기도 동기화
			canvas.width = dicomCanvas.width;
			canvas.height = dicomCanvas.height;

			camCanvas.width = dicomCanvas.width;
			camCanvas.height = dicomCanvas.height;

			// 새로운 캔버스 크기 저장
			canvasWidth = canvas.width;
			canvasHeight = canvas.height;

			// DICOM 이미지를 먼저 그리고 기존 그림을 복원
			drawDicomImage();
			// restoreDrawings(); // 기존 그림 복원
		}
	}

	// 기존의 그린 내용을 스케일링하여 복원
	function scaleCanvasContent() {
		// 이전 크기의 캔버스 내용을 이미지로 저장
		const savedDrawing = new Image();
		savedDrawing.src = canvas.toDataURL();

		// Canvas 초기화
		// ctx.clearRect(0, 0, canvasWidth, canvasHeight);

		savedDrawing.onload = function() {
			ctx.save();
			ctx.scale(canvasWidth / prevCanvasWidth, canvasHeight / prevCanvasHeight);
			ctx.drawImage(savedDrawing, 0, 0);
			ctx.restore();
		};
	}

	function drawDicomImage() {
		if (uploadedImage) {
			const scaleFactor = Math.min(
				dicomCanvas.width / uploadedImage.width,
				dicomCanvas.height / uploadedImage.height
			);
			const newWidth = uploadedImage.width * scaleFactor;
			const newHeight = uploadedImage.height * scaleFactor;
			const offsetX = (dicomCanvas.width - newWidth) / 2;
			const offsetY = (dicomCanvas.height - newHeight) / 2;

			dicomCtx.clearRect(0, 0, dicomCanvas.width, dicomCanvas.height);
			dicomCtx.drawImage(uploadedImage, offsetX, offsetY, newWidth, newHeight);
		}
	}
	// 창 크기 변경 시 리사이즈와 복원 함수 호출
	window.addEventListener('resize', adjustCanvasSize);

	// 초기 설정
	adjustCanvasSize();
	// ctx.restore()

	// 화면 업데이트 함수
	function updateScreen(imgData) {
		if (imgData.length > 0) {
			// imgData 배열의 첫 번째 항목에서 xrayImgPath를 가져옴
			const xrayImgPath = `/diagnosis/xray/getImage?xrayCode=${encodeURIComponent(xrayCode)}`;

			xrayCode = imgData[0].xrayCode;
			localStorage.setItem('xrayCode', xrayCode); // localStorage에 저장
			console.log('Updated xrayCode:', xrayCode);

			// 이미지 경로가 있으면 Canvas에 이미지를 로드
			loadImageToCanvas(xrayImgPath); // HTTP URL로 변환된 경로 사용

			// xrayCode를 사용해 서버에서 데이터 가져오기
			fetchOpinionAndUpdate();
			// 페이지가 변경될 때마다 호출 (예: xrayCode가 바뀔 때마다 호출)
			fetchDiagnosisResults(xrayCode);

		}
	}
	// 이미지 업로드 이벤트 (input 파일 선택 시 캔버스에 표시)
	imageLoader.addEventListener('change', (e) => {
		const file = e.target.files[0];
		if (!file) return;

		const reader = new FileReader();
		reader.onload = (event) => loadImageToCanvas(event.target.result);
		reader.readAsDataURL(file);
	});

	window.uploadedImage = uploadedImage; // 전역으로 설정하여 2.js에서 접근 가능


	// 페이지네이션 렌더링 함수
	function renderPagination() {

		paginationContainer.innerHTML = ''; // 기존 페이지네이션 내용 지우기

		const totalPages = Math.ceil(data.length / itemsPerPage);

		for (let i = 1; i <= totalPages; i++) {
			const pageButton = document.createElement('button');
			pageButton.innerText = i;
			pageButton.classList.add('px-3', 'py-1', 'mx-1', 'bg-gray-200', 'hover:bg-gray-300', 'rounded');
			if (i === currentPage) {
				pageButton.classList.add('bg-blue-500', 'text-white'); // 현재 페이지 강조
			}
			pageButton.addEventListener('click', function() {
				currentPage = i;
				renderPage();
				renderPagination();
			});
			paginationContainer.appendChild(pageButton);
		}
	}

	// xrayCode에 맞는 진단 결과를 불러와서 화면에 표시하는 함수
	function fetchDiagnosisResults(xrayCode) {
		const diagnosisResults = document.getElementById('diagnosisResults');
	    const ul = diagnosisResults.querySelector('ul');
	    const maxLiCount = 4; // 고정된 li 개수 설정
	    // 서버에 xrayCode를 쿼리 파라미터로 전달하여 /xray/result 엔드포인트에서 데이터를 가져옴
	    fetch(`/diagnosis/xray/result?xrayCode=${encodeURIComponent(xrayCode)}`)
	        .then(response => response.json()) // JSON 형식으로 응답을 파싱
	        .then(data => {
	            console.log("받는 값:", data); // 응답 데이터 확인
	
	            // 결과 데이터가 없을 경우 Normal 표시
	            if (data.length === 0) {
	                data = [{ name: "Normal", value: "" }];
	            } else {
	                // 데이터가 있을 경우, 확률 값을 포맷
	                data = data.map(item => ({
	                    name: item.labelName,
	                    value: `${item.probability.toFixed(1)}%`
	                }));
	            }
	            
	            // 데이터가 4개 미만일 경우, 빈 항목으로 채우기
	            while (data.length < maxLiCount) {
	                data.push({ name: " ", value: " " });
	                
	            }
	
	            // diagnosisResults 요소의 <ul> 내 기존 내용을 제거
	            ul.innerHTML = "";
	
	            // 변환된 data 배열을 반복하여 HTML에 동적 <li> 요소 추가
	            data.forEach(result => { // 최대 maxLiCount개의 li만 생성
	                // <li> 요소 생성하여 각각의 결과를 표시할 준비
	                const li = document.createElement('li');
	                li.classList.add('flex', 'justify-between', 'items-center'); // CSS 클래스 추가하여 요소 스타일링
	
	                // <li>의 innerHTML을 설정하여 라벨 이름과 확률 값을 포함한 HTML 텍스트 추가
	                li.innerHTML = `<span>${result.name}</span><span class="font-semibold">${result.value}</span>`;
	
	                // <ul> 요소에 <li>를 추가하여 화면에 결과를 표시
	                ul.appendChild(li);
	            });
	        })
	        // 에러 발생 시 콘솔에 오류 메시지 출력
	        .catch(error => console.error('Error fetching label probabilities:', error));
	}



	// 서버에서 xrayCode로 데이터 가져오기
	function fetchOpinionAndUpdate() {
		if (xrayCode) {
			/*console.log('X-ray Code:', xrayCode);*/

			// X-ray 코드로 서버에서 초기 데이터 가져오기
			fetch(`/diagnosis/xray/dtOpinion?xrayCode=${encodeURIComponent(xrayCode)}`)
				.then(response => {
					if (!response.ok) {
						throw new Error('의견 데이터를 가져오는 데 실패했습니다.');
					}
					return response.text(); // JSON 형식으로 반환받음
				})
				.then(data => {
					console.log("Received data from server:", data);
					doctorOpinionTextarea.value = data || ""; // JSON 내 원하는 값만 추출
				})
				.catch(error => {
					console.error('의사 소견 데이터를 가져오는 중 오류 발생:', error);
				});
		} else {
			console.error('xrayCode가 없습니다. 다시 확인하세요.');
		}
	}

	// 전송 버튼 클릭 시 의견 업데이트
	saveButton.addEventListener('click', function() {
		const updatedOpinion = doctorOpinionTextarea.value;
		/*console.log('Textarea:', updatedOpinion);*/


		if (xrayCode && updatedOpinion) {
			fetch(`/diagnosis/xray/doUpload`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
				},
				body: new URLSearchParams({
					xrayCode: xrayCode,
					dtOpinion: updatedOpinion,
				}),
			})
				.then(response => {
					if (!response.ok) {
						throw new Error('의견 업데이트에 실패했습니다.');
					}
					return response.text();
				})
				.then(message => {
					alert(message);
				})
				.catch(error => {
					console.error('의견 업데이트 중 오류 발생:', error);
					alert('의견 업데이트 중 오류가 발생했습니다.');
				});
		} else {
			alert('의사 소견을 입력해주세요.');
		}
	});

	// 초기 데이터 가져오기
	fetch(`/diagnosis/xray/dateList?ptCode=${encodeURIComponent(ptCode)}`)
		.then(response => response.json())
		.then(fetchedData => {
			data = fetchedData;
			renderPage();
		})
		.catch(error => console.error('Error fetching dateList:', error));
});


